// Aquí irían las funciones relacionadas con la encriptación y desencriptación
// utilizando AES-256.
